# Notes by ztobs #
A simple note taking app build without frameworks. Just html, css, javascript